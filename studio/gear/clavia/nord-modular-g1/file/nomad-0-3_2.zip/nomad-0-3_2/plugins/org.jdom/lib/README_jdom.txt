The jdom.jar file comes from the JDom project:
  http://www.jdom.org/

2007.03.05  -  The jdom.jar file was built from CVS source without modifications.

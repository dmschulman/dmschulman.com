The cssparser.jar file comes from the CSSParser project:
  http://cssparser.sourceforge.net/

2007.03.05  -  The sac.jar file was built from CVS source without modifications.
